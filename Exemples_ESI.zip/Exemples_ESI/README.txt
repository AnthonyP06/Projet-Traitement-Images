Voici quatre fichiers image pour tester vos programmes.
Les versions png et esi correspondantes vous sont fournies, les tailles résultantes sont spécifiées dans le nom des fichiers esi. Vous préférerez probablement commencer par les images de plus petite taille... ;-)

Cup et grey ont été encodées à la main, les images plus grandes ont été générées par un programme similaire à celui que vous devez écrire dans le cadre de ce projet à partir des png source.

g.baudic@isae.fr
2014-03-26

